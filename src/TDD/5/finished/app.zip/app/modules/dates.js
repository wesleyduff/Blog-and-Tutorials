
const dates = (() => {

    return {
        getFormattedDate: () => {}
    }

})();

module.exports = dates;