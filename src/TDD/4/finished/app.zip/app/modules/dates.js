
const dates = (() => {

    return {

    }

})();

module.exports = dates;